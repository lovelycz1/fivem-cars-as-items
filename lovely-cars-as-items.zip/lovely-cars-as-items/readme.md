# How to use

1. Add the vehicle you want to spawn in the config.lua
2. Create item in ox_inventory (If you dont know how look into item.md)

# And its done. Its really easy to setup this script