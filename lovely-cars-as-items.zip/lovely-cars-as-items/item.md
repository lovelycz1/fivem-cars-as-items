# This is how to create the item

1. Go to ox_inventory\data\items.lua
2. Create item like this:
	['name.of.the.car.in.config'] = {
		label = 'Name of the item',
        stack = false,
        description = "Car"
	},

# And its done.