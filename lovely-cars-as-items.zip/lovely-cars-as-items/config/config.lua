Config = {}



Config.Framework = 'esx'     -- 'qb', 'esx'
Config.Notify = 'esx'        -- 'qb', 'esx', 'ox' 
Config.Target = 'ox'        -- 'qb', 'ox'
Config.Inventory = 'ox'     -- 'ox'


Config.Bikes = { 
	"adder", 
-- add more like this:	"faggio2", 

}
